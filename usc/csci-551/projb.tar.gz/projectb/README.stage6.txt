a) Reused Code
no

b) Complete
Totally completed
There is a known bug: sometimes using curl, I can not get meaning response in console. And sometimes
I get decode error. I can not figure out why.

c) Multiplexing
According to ip address(ethN)