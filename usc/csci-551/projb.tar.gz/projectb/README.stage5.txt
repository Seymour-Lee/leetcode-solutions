a) Reused Code
no

b) Complete
Totally completed

c) Authentication
Unauthorized switches will get into our network.
Messages are all unencrypted.


