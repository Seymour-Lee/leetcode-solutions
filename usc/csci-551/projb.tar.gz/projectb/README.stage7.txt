a) Reused Code
no

b) Complete
Not totally completed.
There is a problem: I can send message outside world and get response in r2.
I can also send pakcet from r2 to r1, but r1 can not send to primary router.

c) Diversion with normal routers
Generally, we can not program routing table. Also, changing routing table costs a lot.