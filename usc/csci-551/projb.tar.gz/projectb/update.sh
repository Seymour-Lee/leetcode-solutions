#!/bin/sh

cd ..

scp -r projectb seymourlee@40.83.141.67:/home/seymourlee

