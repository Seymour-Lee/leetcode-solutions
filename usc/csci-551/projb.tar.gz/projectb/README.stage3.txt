a) Reused Code
no

b) Complete
Totally completed

c) Addressing on the way out of your router
We do not want outside world know our address, and we can not get reply message without rewriting.

d) Addressing on the way in to the VM
To avoid getting packet sent by VM

e) Addressing from the VM to the host
Just doing like we do in this project, transfer the packet from VM, rewrite headers and send to outside world.