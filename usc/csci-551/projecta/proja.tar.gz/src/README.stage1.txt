a) Reused Code:
    No reused codes and my makefile is modified from a generic makefile.
   
b) Complete:
    Totally compelete

c) Portable:
    Personally, I think my program should work on different computer architecture, because I do not use
    CPU related codes. 